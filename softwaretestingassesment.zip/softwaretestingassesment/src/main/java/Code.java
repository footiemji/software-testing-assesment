import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Code {

    // Complete the miniMaxSum function below.
    static void miniMaxSum(int[] arr)
    {
        int min=0;
        int max=0;
        //long
        long totalsum=0;

        //Arrays.sort(arr);

        for(int i=0; i<arr.length;i++)
        {
            if(i>0)
            {
                totalsum+=arr[i];
            }
            if(i<4)
            {
                totalsum+=arr[i];
            }
        }
        System.out.println((totalsum-min) + " " +(totalsum-max));
    }
}