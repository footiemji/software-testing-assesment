package Tests;

import Pages.SauceDemoPage;
import Pages.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.IsNull.nullValue;

public class sauceDemoPageTests extends TestBase {

    SauceDemoPage sauceDemoPage;



    @BeforeClass
    public void before() throws Exception {
        super.before();
sauceDemoPage=new SauceDemoPage(getWebDriver());
getWebDriver().get(getSiteURL());


    }

    @Test
    public void checkout()throws Exception {

        sauceDemoPage.checkout();
    }


}
