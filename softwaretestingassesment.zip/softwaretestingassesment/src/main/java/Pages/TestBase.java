package Pages;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;


    public class TestBase {


        //public RemoteWebDriver driver;
        WebDriver driver;

        @BeforeClass
        public void before() throws Exception {

       /* ChromeOptions cap = new ChromeOptions();
        WebDriver driver = new RemoteWebDriver(new URL("http://18.221.40.104:4444/wd/hub"), cap);*/

            /*ChromeOptions options = new ChromeOptions();
            //options.addArguments("disable-infobars");
            driver = new RemoteWebDriver(new URL("http://18.221.40.104:4444/wd/hub"), options);

            FirefoxOptions options1 = new FirefoxOptions();
            driver = new RemoteWebDriver(new URL("http://18.221.40.104:4444/wd/hub"), options1);*/


            System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();





        }

        protected String getSiteURL() {
            String URL = System.getProperty("testUrl");
            if (URL == null) {
                return "https://www.saucedemo.com/inventory.html";

            } else {
                return URL;
            }

        }
            @AfterClass
            public void after () {
                if (driver != null) {
                    driver.quit();

                }
            }

            public WebDriver getWebDriver () {
                return driver;
            }

        }


