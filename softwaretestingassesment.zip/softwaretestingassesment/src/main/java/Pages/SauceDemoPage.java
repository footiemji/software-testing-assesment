package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

public class SauceDemoPage extends TestBase {


    public String username = "evancem@ozow.com";
    public String Password = "T3mpP@ssw0rd";

    //staging elements
    @FindBy(xpath = "//*[@id=\"inventory_filter_container\"]/div")
    public WebElement Heading_products;

    @FindBy(id = "item_4_img_link")
    public WebElement Item_backpack;

    @FindBy(xpath = "//*[@id=\"inventory_item_container\"]/div/div/div/div[3]")
    public WebElement Item_backpack_price;

    @FindBy(xpath = "//*[@id=\"item_4_title_link\"]/div")
    public WebElement Item_backpack_page;

    @FindBy(xpath = "//*[@id=\"inventory_item_container\"]/div/div/div/button")
    public WebElement Item_backpack_AddToCart_;

    @FindBy(css = "#shopping_cart_container > a > svg")
    public WebElement Item_backpack_checkout_Trolly;

    @FindBy(xpath = "//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")
    public WebElement checkout_button;

    @FindBy(id = "first-name")
    public WebElement first_name;

    @FindBy(id = "last-name")
    public WebElement last_name;

    @FindBy(id = "postal-code")
    public WebElement Zipcode;

    @FindBy(xpath = "//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")
    public WebElement Continue_checkout;

    public void checkout()throws Exception{

        Heading_products.isDisplayed();
        Item_backpack.click();
        //Assert.assertTrue(Item_backpack_price.getText().contentEquals("29.99"));
        Item_backpack_AddToCart_.click();

        Item_backpack_checkout_Trolly.click();
        checkout_button.click();
        first_name.sendKeys("ntombi");
        last_name.sendKeys("mjiyako");
        Zipcode.sendKeys("2118");
        checkout_button.click();


    }




    public SauceDemoPage(WebDriver driver){

        PageFactory.initElements(new AjaxElementLocatorFactory(driver,60),this);
    }
}